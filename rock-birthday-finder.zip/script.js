const months=["January","February","March","April","May","June","July","August","September","October","November","December"];
const monthSelect=document.getElementById("month");
months.forEach(m=>{const o=document.createElement("option");o.textContent=m;monthSelect.appendChild(o);});

const artists=[
{name:"Ozzy Osbourne",band:"Black Sabbath",range:["January",1,14],image:"images/ozzy.jpg",description:"Prince of Darkness and heavy metal pioneer."},
{name:"Lemmy",band:"Motorhead",range:["January",15,31],image:"images/lemmy.jpg",description:"Legendary bassist and founder of Motorhead."},
{name:"Kerry King",band:"Slayer",range:["February",1,14],image:"images/kerry.jpg",description:"Thrash metal guitar icon."},
{name:"Marty Friedman",band:"Megadeth",range:["February",15,29],image:"images/marty.jpg",description:"Known for melodic and technical solos."},
{name:"Jimi Hendrix",band:"The Jimi Hendrix Experience",range:["March",1,14],image:"images/jimi.jpg",description:"One of the greatest guitarists ever."},
{name:"Lars Ulrich",band:"Metallica",range:["March",15,31],image:"images/lars.jpg",description:"Metallica co-founder and drummer."},
{name:"Dimebag Darrell",band:"Pantera",range:["April",1,14],image:"images/dimebag.jpg",description:"Beloved metal guitar hero."},
{name:"Phil Collins",band:"Genesis",range:["April",15,30],image:"images/phil.jpg",description:"Singer, songwriter, and drummer."},
{name:"Kirk Hammett",band:"Metallica",range:["May",1,14],image:"images/kirk.jpg",description:"Master of memorable guitar solos."},
{name:"Axl Rose",band:"Guns N' Roses",range:["May",15,31],image:"images/axl.jpg",description:"One of rock's most recognizable voices."},
{name:"2-D",band:"Gorillaz",range:["June",1,14],image:"images/2d.jpg",description:"Animated frontman of Gorillaz."},
{name:"Murdoc",band:"Gorillaz",range:["June",15,30],image:"images/murdoc.jpg",description:"Chaotic fictional bassist."},
{name:"Dave Mustaine",band:"Megadeth",range:["July",1,14],image:"images/mustaine.jpg",description:"Founder of Megadeth."},
{name:"Slash",band:"Guns N' Roses",range:["July",15,31],image:"images/slash.jpg",description:"Top hat, Les Paul, legendary solos."},
{name:"Kurt Cobain",band:"Nirvana",range:["August",1,14],image:"images/kurt.jpg",description:"Voice of grunge."},
{name:"Dave Grohl",band:"Foo Fighters",range:["August",15,31],image:"images/grohl.jpg",description:"Rock's ultimate all-rounder."},
{name:"Fred Durst",band:"Limp Bizkit",range:["September",1,14],image:"images/fred.jpg",description:"Nu metal frontman."},
{name:"Serj Tankian",band:"System of a Down",range:["September",15,30],image:"images/serj.jpg",description:"Unique and powerful vocalist."},
{name:"James Hetfield",band:"Metallica",range:["October",1,14],image:"images/james.jpg",description:"Riff machine and Metallica co-founder."},
{name:"Corey Taylor",band:"Slipknot",range:["October",15,31],image:"images/corey.jpg",description:"One of modern metal's defining voices."},
{name:"Synyster Gates",band:"Avenged Sevenfold",range:["November",1,14],image:"images/syn.jpg",description:"Virtuoso modern metal guitarist."},
{name:"Chad Smith",band:"Red Hot Chili Peppers",range:["November",15,30],image:"images/chad.jpg",description:"Groove-heavy rock drummer."},
{name:"Flea",band:"Red Hot Chili Peppers",range:["December",1,14],image:"images/flea.jpg",description:"Explosive bassist and performer."},
{name:"Rob Zombie",band:"Solo",range:["December",15,31],image:"images/rob.jpg",description:"Rock musician and filmmaker."}
];

function showArtist(a){
document.getElementById("artistImage").src=a.image;
document.getElementById("artistName").textContent=a.name;
document.getElementById("artistBand").textContent=a.band;
document.getElementById("artistDescription").textContent=a.description;
document.getElementById("result").classList.remove("hidden");
}

function findRockstar(){
const m=month.value;
const d=Number(day.value);
const a=artists.find(x=>x.range[0]===m && d>=x.range[1] && d<=x.range[2]);
if(a) showArtist(a); else alert("No match found.");
}

function randomArtist(){
showArtist(artists[Math.floor(Math.random()*artists.length)]);
}
